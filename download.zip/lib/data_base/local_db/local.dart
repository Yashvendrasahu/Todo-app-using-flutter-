
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class HelperDB {
  // Singleton
  HelperDB._();
  static final HelperDB instance = HelperDB._();

  static const String tableNote = "note";
  static const String columnNoteSno = "s_no";
  static const String columnInfo = "info";
  static const String columnDisp = "disp"; // Corrected typo from "Disp" to "disp" for consistency

  Database? _myDB;

  Future<Database> getDB() async {
    if (_myDB != null) {
      return _myDB!;
    } else {
      _myDB = await _openDB();
      return _myDB!;
    }
  }

  Future<Database> _openDB() async {
    if (kIsWeb) {
      // sqflite does not support web. You might need a different implementation for web.
      throw UnsupportedError('sqflite is not supported on web.');
    }
    Directory appDir = await getApplicationDocumentsDirectory();
    String dbPath = join(appDir.path, "note.db");
    return await openDatabase(
      dbPath,
      version: 1,
      onCreate: (db, version) {
        // Corrected SQL syntax
        db.execute(
          "CREATE TABLE $tableNote($columnNoteSno INTEGER PRIMARY KEY AUTOINCREMENT, $columnInfo TEXT, $columnDisp TEXT)",
        );
      },
    );
  }

  // Add queries

  // Insert
  Future<bool> addNote({required String title, required String disc}) async {
    var db = await getDB();
    int rowsAffected = await db.insert(
      tableNote,
      {
        columnInfo: title,
        columnDisp: disc,
      },
    );
    return rowsAffected > 0;
  }

  // Get all notes
  Future<List<Map<String, dynamic>>> getAllNotes() async {
    var db = await getDB();
    List<Map<String, dynamic>> data = await db.query(tableNote);
    return data;
  }

  // Update a note
  Future<bool> updateNote({
    required int sno,
    required String title,
    required String disc,
  }) async {
    var db = await getDB();
    int rowsAffected = await db.update(
      tableNote,
      {
        columnInfo: title,
        columnDisp: disc,
      },
      where: "$columnNoteSno = ?",
      whereArgs: [sno], // Using whereArgs to prevent SQL injection
    );
    return rowsAffected > 0;
  }

  // Delete a note
  Future<bool> deleteNote({required int sno}) async {
    var db = await getDB();
    int rowsAffected = await db.delete(
      tableNote,
      where: "$columnNoteSno = ?",
      whereArgs: [sno], // Using whereArgs to prevent SQL injection
    );
    return rowsAffected > 0;
  }
}
